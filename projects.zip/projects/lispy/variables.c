#include <stdbool.h>
#include "mpc.h"

#ifdef _WIN32

static char buffer[2048];

char* readline(char* prompt) {
  fputs(prompt, stdout);
  fgets(buffer, 2048, stdin);
  char* cpy = malloc(strlen(buffer)+1);
  strcpy(cpy, buffer);
  cpy[strlen(cpy)-1] = '\0';
  return cpy;
}

void add_history(char* unused) {}

#else
#include <readline/readline.h>
#include <readline/history.h>
#endif

/* Create Enumeration of Possible Error Types */
enum { LERR_DIV_ZERO, LERR_BAD_OP, LERR_BAD_NUM };

/* Create Enumeration of Possible lval Types */
enum { LVAL_NUM, LVAL_SYM, LVAL_PAIR, LVAL_SEXPR };

/* Declare New lval Struct */
typedef struct lval {
  int type;
  union {
    long num;
    char* sym;
    struct {
      struct lval* car;
      struct lval* cdr;
    } pair;
  } value;
} lval;

/* Create a new number type lval */
lval* lval_num(long x) {
  lval* v = malloc(sizeof(lval));
  v->type = LVAL_NUM;
  v->value.num = x;
  return v;
}

/* Create a new symbol type lval */
lval* lval_sym(char* s) {
  lval* v = malloc(sizeof(lval));
  v->type = LVAL_SYM;
  v->value.sym = malloc(strlen(s) + 1);
  strcpy(v->value.sym, s);
  return v;
}

/* Create a new pair type lval */
lval* lval_pair(lval* car, lval* cdr) {
  lval* v = malloc(sizeof(lval));
  v->type = LVAL_PAIR;
  v->value.pair.car = car;
  v->value.pair.cdr = cdr;
  return v;
}

mpc_parser_t* Lispy;
void prompt(mpc_parser_t* Lispy);

void lval_err(char* err) {
  fprintf(stderr, "%s\n", err);
  prompt(Lispy);
}

void lval_del(lval* v) {
  
  if (v == NULL) return;

  switch (v->type) {
    /* Do nothing special for number type */
    case LVAL_NUM: break;
    
    /* For Sym free the string data */
    case LVAL_SYM: free(v->value.sym); break;
    
    /* Do nothing special for pair type */
    case LVAL_PAIR:
      /* Possibly free the two children here, recursively */
      /* We leave open here the possibility of dangling lists */
      /* To be taken care of by a garbage collector */
      break;
  }
  
  /* Free the memory allocated for the "lval" struct itself */
  free(v);
}

void lval_del_list(lval* v) {
  
  if (v == NULL) return;
  
  if (v->type == LVAL_PAIR || v->type == LVAL_SEXPR) {
    lval_del_list(v->value.pair.car);
    lval_del_list(v->value.pair.cdr);
  }
  
  lval_del(v);
}

void lval_expr_print(lval* v, char open, char close);

void lval_print(lval* v) {
  
  /* If null, print an empty list and return */
  if (v == NULL) {
    printf("()");
    return;
  }
  
  /* Non-null lval */
  switch (v->type) {
    case LVAL_NUM:   printf("%li", v->value.num); break;
    case LVAL_SYM:   printf("%s", v->value.sym); break;
    case LVAL_PAIR:
      lval_print(v->value.pair.car);
      printf(" . ");
      lval_print(v->value.pair.cdr);
      break;
    case LVAL_SEXPR:
      lval_expr_print(v, '(', ')');
      break;
  }
}

void lval_expr_print_helper(lval* v) {
  if (v != NULL) {
    lval_print(v->value.pair.car);
    if (v->value.pair.cdr != NULL) {
      printf(" ");
      lval_expr_print_helper(v->value.pair.cdr);
    }
  }
}

void lval_expr_print(lval* v, char open, char close) {
  putchar(open);
  lval_expr_print_helper(v);
  putchar(close);
}

void lval_println(lval* v) { lval_print(v); putchar('\n'); }

lval* lval_read_num(mpc_ast_t* t) {
  errno = 0;
  long x = strtol(t->contents, NULL, 10);
  if (errno == ERANGE) lval_err("Invalid number.");
  return lval_num(x); 
}

lval* lval_read(mpc_ast_t* t) {
  
  /* If Symbol or Number return conversion to that type */
  if (strstr(t->tag, "number")) { return lval_read_num(t); }
  if (strstr(t->tag, "symbol")) { return lval_sym(t->contents); }
  
  /* If root (>) or sexpr then create empty list */
  lval* x = NULL;
  
  /* Fill this list with any valid expression contained within */
  for (int i = t->children_num-2; i >0; i--) {
    x = lval_pair(lval_read(t->children[i]), x);
  }
  
  if (x != NULL) x->type = LVAL_SEXPR;
  return x;
}

bool all_numbers(lval* a) {
  if (a == NULL) return true;
  if (a->value.pair.car->type != LVAL_NUM) return false;
  return all_numbers(a->value.pair.cdr);
}

lval* builtin_op(lval* a, char* op) {
  
  /* Ensure all arguments are numbers */
  if (!all_numbers(a)) {
    lval_err("Non-numeric argument to built-in operator.");
  }
  
  lval* x = a->value.pair.car;
  lval* y = a->value.pair.cdr;
  
  long result = x->value.num;
  
  /* While there are still elements remaining */
  while (y != NULL) {
    
    lval* ycar = y->value.pair.car;
    
    /* Perform operation */
    if (strcmp(op, "+") == 0) { result += ycar->value.num; }
    if (strcmp(op, "-") == 0) { result -= ycar->value.num; }
    if (strcmp(op, "*") == 0) { result *= ycar->value.num; }
    if (strcmp(op, "/") == 0) {
      if (ycar->value.num == 0) {
        lval_err("Division by zero.");
      }
      result /= ycar->value.num;
    }
    
    y = y->value.pair.cdr;
  }
  
  return lval_num(result);
}

long c_length(lval* a) {
  if (a == NULL) return 0;
  else return 1 + c_length(a->value.pair.cdr);
}

#define LASSERT(cond, err) \
  if (!(cond)) { lval_err(err); }

#define LASSERT_LENGTH(a, n, err) \
  if (c_length(a) != n) { lval_err(err); }

lval* builtin_length(lval* a) {
  if (a == NULL) return lval_num(0);
  LASSERT_LENGTH(a, 1, "Wrong number arguments to length.");
  lval* temp = a->value.pair.car;
  LASSERT(temp->type == LVAL_PAIR || temp->type == LVAL_SEXPR, "Length called on non-pair.");
  return lval_num(c_length(temp));
}

lval* builtin_quote(lval* a) {
  LASSERT_LENGTH(a, 1, "Wrong number arguments to quote.");
  return a->value.pair.car;
}

lval* builtin_car(lval* a) {
  LASSERT_LENGTH(a, 1, "Wrong number arguments to car.");
  lval* temp = a->value.pair.car;
  LASSERT(temp->type == LVAL_PAIR || temp->type == LVAL_SEXPR, "Car called on non-pair.");
  return temp->value.pair.car;
}

lval* builtin_cdr(lval* a) {
  LASSERT_LENGTH(a, 1, "Wrong number arguments to cdr.");
  lval* temp = a->value.pair.car;
  LASSERT(temp->type == LVAL_PAIR || temp->type == LVAL_SEXPR, "Cdr called on non-pair.");
  return temp->value.pair.cdr;
}

lval* builtin_cadr(lval* a) {
  LASSERT_LENGTH(a, 1, "Wrong number arguments to cadr.");
  lval* temp = a->value.pair.car;
  LASSERT(temp->type == LVAL_PAIR || temp->type == LVAL_SEXPR, "Cadr called on non-pair.");
  temp = temp->value.pair.cdr;
  LASSERT(temp->type == LVAL_PAIR || temp->type == LVAL_SEXPR, "Cadr called on non-pair.");
  return temp->value.pair.car;
}

lval* builtin_cons(lval* a) {
  LASSERT_LENGTH(a, 2, "Wrong number of arguments to cons.");
  
  lval* result = lval_pair(a->value.pair.car, a->value.pair.cdr->value.pair.car);
  return result;
}

lval* builtin(lval* a, char* func) {
  if (strcmp("length", func) == 0) { return builtin_length(a); }
  if (strcmp("cons", func) == 0) { return builtin_cons(a); }
  if (strcmp("cadr", func) == 0) { return builtin_cadr(a); }
  if (strcmp("car" , func) == 0) { return builtin_car(a);  }
  if (strcmp("cdr" , func) == 0) { return builtin_cdr(a);  }
  if (strstr("+-*/", func)) { return builtin_op(a, func); }
  
  lval_err("Unknown function.");
}

lval* lval_eval(lval* v);

lval* lval_eval_sexpr(lval* v) {
  
  if (v == NULL) return v;
  if (v->type != LVAL_SEXPR) {
    lval_err("Not an s-expression.");
  }
  
  /* Ensure First Element is Symbol */
  lval* f = v->value.pair.car;
  lval* a = v->value.pair.cdr;
  if (f->type != LVAL_SYM) {
    lval_err("S-expression does not start with symbol.");
  }
  
  if (strcmp(f->value.sym, "quote") == 0) return builtin_quote(a);
  
  /* Evaluate arguments */
  lval* temp = a;
  while (temp != NULL) {
    lval* result = lval_eval(temp->value.pair.car);
    temp->value.pair.car = result;
    temp = temp->value.pair.cdr;
  }
  
  lval* result = builtin(a, f->value.sym);
  return result;
}

lval* lval_eval(lval* v) {
  
  if (v == NULL) return v;
  
  /* Evaluate S-expressions */
  if (v->type == LVAL_SEXPR) { return lval_eval_sexpr(v); }
  
  /* All other lval types remain the same */
  return v;
}

void prompt(mpc_parser_t* Lispy) {
  char* input = readline("lispy> ");
  add_history(input);
  
  mpc_result_t r;
  if (mpc_parse("<stdin>", input, Lispy, &r)) {
    // mpc_ast_print(r.output);
    lval* x = lval_read(r.output);
    lval* temp = x;
    while (temp != NULL) {
      lval* result = lval_eval(temp->value.pair.car);
      lval_println(result);
      temp = temp->value.pair.cdr;
    }
    lval_del_list(x);
    mpc_ast_delete(r.output);
  } else {    
    mpc_err_print(r.error);
    mpc_err_delete(r.error);
  }
  
  free(input);
  prompt(Lispy);
}

int main(int argc, char** argv) {
  
  mpc_parser_t* Number = mpc_new("number");
  mpc_parser_t* Symbol = mpc_new("symbol");
  mpc_parser_t* Sexpr  = mpc_new("sexpr");
  mpc_parser_t* Expr   = mpc_new("expr");
  Lispy  = mpc_new("lispy");
  
  mpca_lang(MPCA_LANG_DEFAULT,
    "                                          \
      number : /-?[0-9]+/ ;                    \
      symbol : /[A-Za-z!&+\\-*\\/=<>_][A-Za-z0-9!&+\\-*\\/=<>_]*/ ;         \
      sexpr  : '(' <expr>* ')' ;               \
      expr   : <number> | <symbol> | <sexpr> ; \
      lispy  : /^/ <expr>* /$/ ;               \
    ",
    Number, Symbol, Sexpr, Expr, Lispy);
  
  puts("Lispy Version 0.0.0.0.5");
  puts("Press Ctrl+c to Exit\n");
  
  prompt(Lispy);
  
  mpc_cleanup(5, Number, Symbol, Sexpr, Expr, Lispy);
  
  return 0;
}

