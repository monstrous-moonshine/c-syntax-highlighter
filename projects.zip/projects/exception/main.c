#include "throw.h"

int main() {
  seppuku();
}