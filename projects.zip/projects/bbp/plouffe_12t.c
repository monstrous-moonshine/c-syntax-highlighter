#include <stdio.h>
#include <stdlib.h>
#include <quadmath.h>
#include <pthread.h>
#include <unistd.h>

typedef struct {
  long d;
  long j;
  long kstart;
  long kend;
  __float128 s;
} arguments;

/* Return the fractional part */
__float128 fpart(__float128 x) {
  return x - floorq(x);
}

/* Compute b^e (mod m) */
__int128 expmod(__int128 b, long e, long m) {
  if (e == 0) return 1;
  if (e%2 == 1) return (b * expmod(b, e-1, m)) % m;
  
  __int128 x = expmod(b, e/2, m);
  return (x * x) % m;
}

/* Do a chunk of the work */
void* s_helper(void* argsptr) {
  arguments* args = (arguments*) argsptr;
  __float128 t2 = 0;
  
  for (long k = args->kstart; k <= args->kend; k++) {
    t2 += 1.0Q * expmod(16, args->d - k, 8 * k + args->j) / (8 * k + args->j);
  }
  
  args->s = fpart(t2);
}

/* Return the fractional part for one term in the BBP formula */
void* s(void* argsptr) {
  arguments* args = (arguments*) argsptr;
  __float128 t1 = -1, t2 = 0;
  
  arguments nargs[3]; // new args
  pthread_t threads[3];
  
  for (int i = 0; i < 3; i++) {
    nargs[i].d = args->d;
    nargs[i].j = args->j;
  }
  
  nargs[0].kstart = 0;
  nargs[0].kend = args->d / 3;
  
  nargs[1].kstart = nargs[0].kend + 1;
  nargs[1].kend = 2 * nargs[0].kend;
  
  nargs[2].kstart = nargs[1].kend + 1;
  nargs[2].kend = args->d;
  
  for (int i = 0; i < 3; i++) {
    pthread_create(&threads[i], NULL, s_helper, &nargs[i]);
  }
  
  for (int i = 0; i < 3; i++) {
    pthread_join(threads[i], NULL);
  }
  
  t2 = fpart(nargs[0].s + nargs[1].s + nargs[2].s);
  
  // second part
  /* If there seems to be an infinite loop, check the exit condition here */
  __float128 den = 16;
  for (long k = args->d + 1; t2 - t1 > 1e-34Q; k++) {
    t1 = t2;
    t2 = t1 + 1.0Q / (8 * k + args->j) / den;
    den *= 16;
  }
  
  args->s = fpart(t2);
}

/* Combine the terms obtained by the s-function appropriately */
__float128 plouffe(long d) {
  pthread_t threads[4];
  arguments args[4];
  
  for (int i = 0; i < 4; i++) {
    args[i].d = d;
  }
  
  args[0].j = 1;
  args[1].j = 4;
  args[2].j = 5;
  args[3].j = 6;
  
  for (int i = 0; i < 4; i++) {
    pthread_create(&threads[i], NULL, s, &args[i]);
  }
  
  for (int i = 0; i < 4; i++) {
    pthread_join(threads[i], NULL);
  }
  
  return fpart(4.0Q * args[0].s - 2.0Q * args[1].s - args[2].s - args[3].s);
}

/* Print out the hex digits of a fraction
   Only works for fractional parts now */
void hex_print(__float128 x) {
  char digits[17] = "0123456789ABCDEF";
  __float128 temp = x;
  // printf("0.");
  for (int i = 0; i < 20; i++) {
    int d = (int) (temp * 16);
    printf("%c", digits[d]);
    temp = temp * 16 - d;
  }
}

int main(int argc, char* argv[]) {
  if (argc < 2) {
    printf("Usage: plouffe n\n");
    printf("Prints the hex digits of pi after n digits.\n");
    return 0;
  }
  printf("%ld processors online.\n\n", sysconf(_SC_NPROCESSORS_ONLN));
  long n  = atol(argv[1]);
  char buf[128];
  printf("The hex digits of pi, after %ld digits, are ", n);
  hex_print(plouffe(n));
  printf("...\n");
  return 0;
}