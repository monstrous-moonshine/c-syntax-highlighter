#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "scanner.h"
#include "tokenlist.h"

#define ROW 0
#define COL 0

#define isAlpha(c) (c == '_' || isalpha(c))
#define isAlNum(c) (isAlpha(c) || isdigit(c))
#define ADD_TOKEN(tokenList, tokenType, lexeme) add_token(tokenList, make_token (tokenType, lexeme, ROW, COL))
#define ADD_TOKEN_FROM_LEXEME(tokenType) add_token_from_lexeme(scanner, start, tokenType, tokenList)

void error(const char* msg) {
  // do something here
}

bool isoctdigit(char c) {
  if (isdigit(c) && c < '8') return true;
  else return false;
}

char advance(Scanner scanner) {
  return scanner -> text [ scanner -> pos++ ];
}

char peek(Scanner scanner) {
  return scanner -> text [ scanner -> pos ];
}

char* make_lexeme(Scanner scanner, int start) {
  int len = scanner -> pos - start + 1;
  char* lexeme = (char*) malloc(len * sizeof(char));
  memcpy(lexeme, scanner -> text + start, len - 1);
  lexeme [ len - 1 ] = '\0';
  return lexeme;
}

void add_token_from_lexeme(Scanner scanner, int start, TokenType tokenType , TokenList tokenList) {
  const char* lexeme = make_lexeme(scanner, start);
  Token token = make_token(tokenType, lexeme, ROW, COL);
  add_token(tokenList, token);
}

void whiteSpace(Scanner scanner, TokenList tokenList) {
  int start = scanner -> pos;
  while (isspace(peek(scanner))) advance(scanner);
  ADD_TOKEN_FROM_LEXEME(WHITESPACE);
}

void identifier(Scanner scanner, TokenList tokenList) {
  int start = scanner -> pos;
  while (isAlNum(peek(scanner))) advance(scanner);
  ADD_TOKEN_FROM_LEXEME(IDENTIFIER);
}

// incomplete
void number(Scanner scanner, TokenList tokenList) {
  int start = scanner -> pos;
  while (isdigit(peek(scanner))) advance(scanner);
  ADD_TOKEN_FROM_LEXEME(NUMBER);
}

void escapeseq(Scanner scanner, TokenList tokenList) {
  switch (advance(scanner)) {
    case '\'':
    case '\"':
    case '\?':
    case '\\':
    case 'n':
    case 'r':
    case 't': break;
    default: error("Invalid escape sequence");
  }
}

void charliteral(Scanner scanner, TokenList tokenList) {
  int start = scanner -> pos;
  int i = 0;
  advance(scanner); // consume the '
  while (true) {
    char c = advance(scanner);
    if (c == '\'') {
      if (i < 1) error("Empty character constant");
      else break;
    }
    if (c == '\\') escapeseq(scanner, tokenList);
    if (c == '\n') error("Invalid character constant");
    i++;
  }
  ADD_TOKEN_FROM_LEXEME(CHARLITERAL);
}

void string(Scanner scanner, TokenList tokenList) {
  int start = scanner -> pos;
  advance(scanner); // consume the "
  while (true) {
    char c = advance(scanner);
    if (c == '\"') break;
    if (c == '\\') escapeseq(scanner, tokenList);
    if (c == '\n') error("Invalid character constant");
  }
  ADD_TOKEN_FROM_LEXEME(STRING);
}

// scanner.text points to null terminated string
// containing the source code
// scanner.pos, scanner.row, scanner.col are
// initialized to 0
TokenList scanner_scan(Scanner scanner) {
  TokenList tokenList = make_tokenlist();
  while (peek(scanner) != '\0') {
    char c = peek(scanner);
    if (isspace(c)) whiteSpace(scanner, tokenList);
    else if (isAlpha(c)) identifier(scanner, tokenList);
    else if (isdigit(c)) number(scanner, tokenList);
    else if (c == '\"') string(scanner, tokenList);
    else if (c == '\'') charliteral(scanner, tokenList);
    else switch (advance(scanner)) {
      case ',' : ADD_TOKEN(tokenList, COMMA,    ","); break;
      case ';' : ADD_TOKEN(tokenList, SEMICOLON, ";"); break;
      case '\?' : ADD_TOKEN(tokenList, QUESTION, "\?"); break;
      case ':' : ADD_TOKEN(tokenList, COLON,    ":"); break;
      case '~' : ADD_TOKEN(tokenList, TILDE,    "~"); break;
      case '(' : ADD_TOKEN(tokenList, LPAREN,   "("); break;
      case ')' : ADD_TOKEN(tokenList, RPAREN,   ")"); break;
      case '{' : ADD_TOKEN(tokenList, LBRACE,   "{"); break;
      case '}' : ADD_TOKEN(tokenList, RBRACE,   "}"); break;
      case '[' : ADD_TOKEN(tokenList, LBRACKET, "["); break;
      case ']' : ADD_TOKEN(tokenList, RBRACKET, "]"); break;
      case '^' :
        if (peek(scanner) == '=') {
          advance(scanner);
          ADD_TOKEN(tokenList, CARET_EQ, "^=");
        } else {
          ADD_TOKEN(tokenList, CARET, "^");
        }
        break;
      case '!' :
        if (peek(scanner) == '=') {
          advance(scanner);
          ADD_TOKEN(tokenList, BANG_EQ, "!=");
        } else {
          ADD_TOKEN(tokenList, BANG, "!");
        }
        break;
      case '=' :
        if (peek(scanner) == '=') {
          advance(scanner);
          ADD_TOKEN(tokenList, EQ_EQ, "==");
        } else {
          ADD_TOKEN(tokenList, EQUAL, "=");
        }
        break;
      case '&' :
        switch (peek(scanner)) {
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, AMPERSAND_EQ, "&=");
            break;
          case '&' :
            advance(scanner);
            ADD_TOKEN(tokenList, AND, "&&");
            break;
          default :
            ADD_TOKEN(tokenList, AMPERSAND, "&");
        }
        break;
      case '|' : 
        switch (peek(scanner)) {
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, BAR_EQ, "|=");
            break;
          case '|' :
            advance(scanner);
            ADD_TOKEN(tokenList, OR, "||");
            break;
          default :
            ADD_TOKEN(tokenList, BAR, "|");
        }
        break;
      case '.' :
        if (peek(scanner) == '.') {
          advance(scanner);
          if (peek(scanner) == '.') {
            advance(scanner);
            ADD_TOKEN(tokenList, ELLIPSIS, "...");
          } else {
            error("Unexpected character");
          }
        } else if (isdigit(peek(scanner))) {
          scanner -> pos--;
          number(scanner, tokenList);
        } else {
          ADD_TOKEN(tokenList, DOT , ".");
        }
        break;
      case '+' :
        switch (peek(scanner)) {
          case '+' :
            advance(scanner);
            ADD_TOKEN(tokenList, INCR, "++");
            break;
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, PLUS_EQ, "+=");
            break;
          default :
            ADD_TOKEN(tokenList, PLUS, "+");
        }
        break;
      case '-' :
        switch (peek(scanner)) {
          case '>' :
            advance(scanner);
            ADD_TOKEN(tokenList, ARROW, "->");
            break;
          case '-' :
            advance(scanner);
            ADD_TOKEN(tokenList, DECR, "--");
            break;
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, MINUS_EQ, "-=");
            break;
          default : ADD_TOKEN(tokenList, MINUS, "-"); break;
        }
        break;
      case '*' :
        if (peek(scanner)== '=') {
          advance(scanner);
          ADD_TOKEN(tokenList, STAR_EQ, "*=");
        } else {
          ADD_TOKEN(tokenList, STAR, "*");
        }
        break;
      case '/' :
        switch (peek(scanner)) {
          case '/' :
            while (peek(scanner) != '\n') {
              if (peek(scanner) == '\0') break;
              else advance(scanner);
            }
            break;
          case '*' :
            advance(scanner);
            while (true) {
              if (peek(scanner) == '\0')break;
              if (advance(scanner) == '*' && peek(scanner) == '/') {
                advance(scanner);
                break;
              }
            }
            break;
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, SLASH_EQ, "/=");
            break;
          default :
            ADD_TOKEN(tokenList, SLASH, "/");
        }
        break;
      case '%' :
        if (peek(scanner) == '=') {
          advance(scanner);
          ADD_TOKEN(tokenList, PERCENT_EQ, "%=");
        } else {
          ADD_TOKEN(tokenList, PERCENT, "%");
        }
      case '<' :
        switch (peek(scanner)) {
          case '<' :
            advance(scanner);
            if (peek(scanner) == '=') {
              advance(scanner);
              ADD_TOKEN(tokenList, LSHIFT_EQ, "<<=");
            } else {
              ADD_TOKEN(tokenList, LSHIFT, "<<");
            }
            break;
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, LESS_EQ, "<=");
            break;
          default :
            ADD_TOKEN(tokenList, LESS, "<");
        }
        break;
      case '>' :
        switch (peek(scanner)) {
          case '>' :
            advance(scanner);
            if (peek(scanner) == '=') {
              advance(scanner);
              ADD_TOKEN(tokenList, RSHIFT_EQ, ">>=");
            } else {
              ADD_TOKEN(tokenList, RSHIFT, ">>");
            }
            break;
          case '=' :
            advance(scanner);
            ADD_TOKEN(tokenList, GREATER_EQ, ">=");
            break;
          default :
            ADD_TOKEN(tokenList, GREATER, ">");
        }
        break;
      default :
        error("Unrecognized character");
    }
  }
}

static char* readFile(const char* path) {                        
  FILE* file = fopen(path, "rb");

  fseek(file, 0L, SEEK_END);                                     
  size_t fileSize = ftell(file);                                 
  rewind(file);                                                  

  char* buffer = (char*)malloc(fileSize + 1);                    
  size_t bytesRead = fread(buffer, sizeof(char), fileSize, file);
  buffer[bytesRead] = '\0';                                      

  fclose(file);                                                  
  return buffer;                                                 
}

Scanner scanner_create(const char* source) {
  Scanner scanner = (Scanner) malloc(sizeof *scanner);
  scanner -> text = readFile(source);
  scanner -> pos = 0;
  scanner -> row = 0;
  scanner -> col = 0;
  return scanner;
}

void scanner_destroy(Scanner scanner) {}