#include <stdio.h>
#include <stdlib.h>
#include <cxxabi.h>

int main() {
	const char *mangled_name = "_ZNK3MapI10StringName3RefI8GDScriptE10ComparatorIS0_E16DefaultAllocatorE3hasERKS0_";
	char *demangled_name;
	int status = -1;
	demangled_name = abi::__cxa_demangle(mangled_name, NULL, NULL, &status);
  printf("Mangled: %s\n", mangled_name);
  switch (status) {
    case 0:
      printf("Demangled: %s\n", demangled_name);
      break;
    case -1:
      printf("Memory allocation failure.\n");
      break;
    case -2:
      printf("Invalid mangled name.\n");
      break;
    case -3:
      printf("Invalid argument.\n");
      break;
    default:
      printf("abi::__cxa_demangle returned an invalid status.\n");
  }
	free(demangled_name);
	return 0;
}