#include <stdio.h>
#include "scanner.h"
#include "tokenlist.h"
//#include "parser.h"
//#include "stmtlist.h"

int main(int argc, char* argv[]) {
  if (argc < 2) {
    // handle it
  }
  Scanner scanner = scanner_create(argv[1]);
  TokenList tokens = scanner_scan(scanner);
  //Parser parser = parser_create(tokens);
  //StmtList stmts = parser_parse(parser);
  //print_stmtlist(stmts);
  //stmtlist_destroy(stmts);
  //parser_destroy(parser);
  tokenlist_destroy(tokens);
  scanner_destroy(scanner);
}