#include <iostream>

template <typename T>
struct isPtr {
    static const bool value = false;
};

template <typename T>
struct isPtr<T*> {
    static const bool value = true;
};

template <typename T>
struct isConst {
    static const bool value = false;
};

template <typename T>
struct isConst<T const> {
    static const bool value = true;
};

template <template <typename> typename f1, template <typename> typename f2>
struct or_combinator {
    template <typename T>
    struct lambda {
        static const bool value = f1<T>::value || f2<T>::value;
    };
};

int main() {
    int nonptr;
    int *ptr;
    std::cout << "nonptr is " << (isPtr<int >::value ? "   " : "not") << " a pointer" << std::endl;
    std::cout << "   ptr is " << (isPtr<int*>::value ? "   " : "not") << " a pointer" << std::endl;
    int nonconst;
    int const isconst = 42;
    std::cout << "nonconst is " << (isConst<int      >::value ? "   " : "not") << " const" << std::endl;
    std::cout << " isconst is " << (isConst<int const>::value ? "   " : "not") << " const" << std::endl;
    std::cout 
        << "or_combinator<isPtr, isConst>::lambda<const int>::value = "
        << or_combinator<isPtr, isConst>::lambda<const int>::value 
        << std::endl;
    return 0;
}