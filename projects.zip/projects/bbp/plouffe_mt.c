#include <stdio.h>
#include <stdlib.h>
#include <quadmath.h>
#include <pthread.h>

typedef struct {
  long d;
  long j;
  __float128 s;
} arguments;

/* Return the fractional part */
__float128 fpart(__float128 x) {
  return x - floorq(x);
}

/* Compute b^e (mod m) */
__int128 expmod(__int128 b, long e, long m) {
  if (e == 0) return 1;
  if (e%2 == 1) return (b * expmod(b, e-1, m)) % m;
  
  __int128 x = expmod(b, e/2, m);
  return (x * x) % m;
}

/* Return the fractional part for one term in the BBP formula */
void* s(void* argsptr) {
  arguments* args = (arguments*) argsptr;
  __float128 t1 = -1, t2 = 0;
  
  // first part
  for (long k = 0; k <= args->d; k++) {
    t2 += 1.0Q * expmod(16, args->d - k, 8 * k + args->j) / (8 * k + args->j);
  }
  t2 = fpart(t2);
  
  // second part
  /* If there seems to be an infinite loop, check the exit condition here */
  __float128 den = 16;
  for (long k = args->d + 1; t2 - t1 > 1e-34Q; k++) {
    t1 = t2;
    t2 = t1 + 1.0Q / (8 * k + args->j) / den;
    den *= 16;
  }
  
  args->s = fpart(t2);
}

/* Combine the terms obtained by the s-function appropriately */
__float128 plouffe(long d) {
  pthread_t threads[4];
  arguments ss[4];
  
  for (int i = 0; i < 4; i++) {
    ss[i].d = d;
  }
  
  ss[0].j = 1;
  ss[1].j = 4;
  ss[2].j = 5;
  ss[3].j = 6;
  
  for (int i = 0; i < 4; i++) {
    pthread_create(&threads[i], NULL, s, &ss[i]);
  }
  
  for (int i = 0; i < 4; i++) {
    pthread_join(threads[i], NULL);
  }
  
  return fpart(4.0Q * ss[0].s - 2.0Q * ss[1].s - ss[2].s - ss[3].s);
}

/* Print out the hex digits of a fraction
   Only works for fractional parts now */
void hex_print(__float128 x) {
  char digits[17] = "0123456789ABCDEF";
  __float128 temp = x;
  // printf("0.");
  for (int i = 0; i < 20; i++) {
    int d = (int) (temp * 16);
    printf("%c", digits[d]);
    temp = temp * 16 - d;
  }
}

int main(int argc, char* argv[]) {
  if (argc < 2) {
    printf("Usage: plouffe n\n");
    printf("Prints the hex digits of pi after n digits.\n");
    return 0;
  }
  long n  = atol(argv[1]);
  char buf[128];
  printf("The hex digits of pi, after %ld digits, are ", n);
  hex_print(plouffe(n));
  printf("...\n");
  return 0;
}