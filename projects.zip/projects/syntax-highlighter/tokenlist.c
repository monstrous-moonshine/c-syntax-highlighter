#include "tokenlist.h"
#include <stdlib.h>

TokenList make_tokenlist() {
  TokenList lst = (TokenList) malloc(sizeof *lst);
  lst -> z = (Node*) malloc(sizeof(Node));
  lst -> z -> next = lst -> z;
  lst -> head = lst -> z;
  lst -> tail = lst -> z;
  return lst;
}

void add_token(TokenList lst, Token token) {
  Node* node = (Node*) malloc(sizeof *node);
  memcpy(&node->token, &token, sizeof token);
  node -> next = lst -> z;
  lst -> tail
}

void tokenlist_destroy(TokenList tokenList) {}