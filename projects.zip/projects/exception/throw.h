struct Exception {};

#ifdef __cplusplus
extern "C" {
#endif

  void seppuku();

#ifdef __cplusplus
}
#endif