#include <stdio.h>

int main() {
  printf("We are in function: %s\n", __func__);
}