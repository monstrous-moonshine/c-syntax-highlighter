#include <iostream>

template <typename... list>
struct count;

template <>
struct count<> {
  static const int value = 0;
};

template <typename head, typename... tail>
struct count<head, tail...> {
  static const int value = 1 + count<tail...>::value;
};

int main() {
  std::cout << "count<int, char, long>::value = " << count<int, char, long>::value << std::endl;
}