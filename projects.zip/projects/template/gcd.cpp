#include <iostream>

template <int X, int Y> struct GCD {
  static const int result = GCD<Y, X % Y>::result;
};

template <int X> struct GCD<X, 0> {
  static const int result = X;
};

int main() {
  std::cout << GCD<42, 18>::result << "\n";
}